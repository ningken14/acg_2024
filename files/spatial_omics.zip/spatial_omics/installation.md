# Installation 

## From GitHub
From the R terminal, you can use the following commands:

If you do not have `devtools` already installed, please do so beforehand.

```
install.packages("devtools")
```  
Ensure that the library has been loaded
```
library(devtools)
```
Install Vesalius via GitHub
```
install_github("patrickCNMartin/Vesalius",  dependencies = TRUE)
```

## From source

In the course package you will find the source code of the packages that you can install directly.
From the R terminal, you can use the following commands:

```
install.packages("vesalius_2.0.0.tar.gz", dependencies = TRUE repo = NULL)
```

Note that `vesalius_2.0.0.tar.gz` is the path to the tarball we provide. 

## Dependencies
While R should handle the installation of dependencies, there might be some issues that will lead to the following warning message:

```
Warning in install.packages :
  installation of package ‘package_name’ had non-zero exit status
```

If this is the case, you will need to install that package manually. 

The list of Vesalius dependencies are the following:

```
packages <- c(
    Rcpp,
    grDevices,
    stats,
    utils,
    deldir,
    sp,
    tvR,
    Matrix,
    RColorBrewer,
    future,
    future.apply,
    imagerExtra,
    methods,
    Signac,
    ggpubr,
    lmtest,
    infix,
    Seurat,
    SeuratObject,
    imager,
    DESeq2,
    RANN,
    dplyr,
    edgeR,
    ggplot2,
    igraph,
    pwr,
    purrr,
    patchwork,
    ggnewscale,
    kohonen,
    Rcpp,
    TreeDist,
    knitr,
    RUnit,
    rmarkdown,
    testthat,
    NMF,
    sf)

if (!require("BiocManager")) install.packages("BiocManager")


for(lib in packages){
    if(!lib %in% installed.packages()){
        if(lib %in% available.packages()[,1]){
            install.packages(lib,dependencies=TRUE)
        }else {
            BiocManager::install(lib)
        }
    }
}
```
